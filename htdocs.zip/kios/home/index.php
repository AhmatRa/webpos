<?php 
echo "Welcome";

 ?>