<?php 
include 'config.php';
 ?>

<NAV>
	<a href="#">HOME</a>
</NAV>

<center>
	<form action="" method="GET">
		<input type="text" name="username" placeholder="username">	<br><br>
		<input type="text" name="beli" placeholder="beli">	<br><br>
		<select name="pilih">
			<option>siang</option>
			<option>malam</option>
		</select>
		<input type="submit" name="simpan">	
	</form>	
</center>

<?php 

/*$sql = "SELECT * FROM tb_pembeli";
$result = $conn->query($sql);*/
 $user=$_GET['username'];
 $beli=$_GET['beli'];
 $pilih=$_GET['pilih'];

 if (isset($_GET['simpan'])) {
 	echo $user;
 	echo $beli;
 	echo $pilih;
 }


 ?>