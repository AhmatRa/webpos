 <?php
include 'config.php';

$sql = "SELECT * FROM tb_pembeli";
$result = $conn->query($sql);
?> 

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<table border="1" align="center">
	<thead>
		<tr>
			<td>USER</td>
			<td>BELI</td>
			<td>HABIS</td>
			<td>WAKTU</td>
		</tr>
	</thead>
	<tbody>
	<?php 

	if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) { ?>
    <tr>
    	<td><?=$row['user'];?></td>
    	<td><?=$row['beli'];?></td>
    	<td><?=$row['habis'];?></td>
    	<td><?=$row['waktu'];?></td>
    </tr>

    <?php
    	}
	} else {
    echo "0 results";
	}
	$conn->close();

		 ?>
	</tbody>
</table>
<?=date('d');?>
</body>
</html>
