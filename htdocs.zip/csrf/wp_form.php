 <form action="form1.php" method="POST">
 	<input type="text" name="uri">
 	<input type="submit" name="lock" value="submit">
 </form>
