<?php
//error_reporting(E_ALL ^ E_NOTICE); 
function write($val){
	$fp = fopen('data.txt', 'a');
	$tab="\n";
	fwrite($fp, $val);
	fwrite($fp, $tab);
	fclose($fp);
}
function make($leng){
	for($a=1; $a<=$leng; $a++)
	{
		write($a);
	}
	
}
function read()
{
	$file=file_get_contents('data.txt');
	$ex=explode("\n", $file);
	/*echo "JUMLA DATA = ".sizeof($ex)-1;*/
	shuffle($ex);
	//$arr=array($ex);
	echo "<hr>";
	//echo "<center>";
	echo "<table>";
	echo "<tr>";
	echo "<th>DATA</th>";
	echo "<th>MIN</th>";
	echo "</tr>";
	foreach ($ex as $value) {
		echo "<tr>";
		echo "<td>".$value."</td>";
		echo "</tr>";		
	}
	echo "</table>";
	//echo "</center>";	
}
function clean(){
	$fp = fopen('data.txt', 'w');
	fwrite($fp, "");
	fclose($fp);
}

function min_max(){
	echo "<button name='min'>MIN</button>";
	echo "<br>";
	echo "<button name='max'>MAX</button>";
}
?>

<form action="" method="GET" name="leng">
	<label>JUMLAH DATA</label><br><br>
	<input type="text" name="va" placeholder="example 500"><br><br>
	<button name="hit">PRINT</button>
</form>

<?php 
$va=$_GET['va'];
$cek='data.txt';
if(isset($_GET['hit']))
	{
		if (filter_var($va, FILTER_VALIDATE_INT)) 
		{
			if(!$cek=="")
			{
				clean();
				make($va);
				read();
				
			}
		} 
		else 
		{
			echo("PLEASE INSERT NUMBER");
		}
	}

 ?>
