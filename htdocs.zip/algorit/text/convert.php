<?php
/**************************************
 *                                     |
 * Obet Converter Text to Binary ASCII |
 *                                     |
 *                                     |
 **************************************/
header("Content-Type: text/html; charset=utf-8");
function textBinASCII($text){
	$bin = array();
    for($i=0; strlen($text)>$i; $i++)
    	$bin[] = decbin(ord($text[$i]));

    return implode(' ',$bin);
}

function ASCIIBinText($bin){
	$text = array();
	$bin = explode(" ", $bin);
	for($i=0; count($bin)>$i; $i++)
		$text[] = chr(bindec($bin[$i]));
		
	return implode($text);
}
$gg='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
$bibin=explode(" ", textBinASCII($gg));


$arr=array('a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z');

/*for($x=0;$x<count($arr);$x++){
		//echo $arr[$x]."=>".$bibin[$x]."<br>";
		$nn=$arr[$x];
		$vv=$bibin[$x];
		$narr=array($nn=>$vv);
		foreach ($narr as $key => $value) {
			echo "'$key'=>"."'$value',";
		}
	}*/
	//echo textBinASCII($gg);
?>