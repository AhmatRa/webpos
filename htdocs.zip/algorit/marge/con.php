<?php 
function write($val){
	$fp = fopen('file.csv', 'a');
	$tab="\n";
	fwrite($fp, $val);
	fwrite($fp, $tab);
	fclose($fp);
}
function make($leng){
	for($a=1; $a<=$leng; $a++)
	{
		write($a);
	}
	
}

function read()
{
	$file=file_get_contents('file.csv');
	//$arr=array($file);
	$ex=explode("\n", $file);
	shuffle($ex);
	foreach ($ex as $value) {
		echo $value."<br>";
	}
}

function clean(){
	$fp = fopen('file.csv', 'w');
	fwrite($fp, "");
	fclose($fp);
}




 ?>