<?php 
function write($val){
	$fp = fopen('file.csv', 'a');
	$tab=" ";
	fwrite($fp, $val);
	fwrite($fp, $tab);
	fclose($fp);
}
function make($leng){
	for($a=1; $a<=$leng; $a++)
	{
		write($a);
	}
	
}
?>

<form action="" method="GET" name="leng">
	<label>JUMLAH DATA</label><br><br>
	<input type="text" name="va" placeholder="example 500"><br><br>
	<button name="hit">buat</button>
</form>

<?php 
if(isset($_GET['hit']))
{
	make($_GET['va']);
}

 ?>