<?php 
$file=file_get_contents('file.csv');
$ex=explode(" ", $file);
echo "DATA AWAL <br>";

foreach ($ex as $e) {
	echo $e." ";
}
echo "<hr>";
$k=array_chunk($ex,4,true);
	foreach ($k as $key => $value) 
	{
		$min=min($value);
		$max=max($value);
		foreach ($value as $pembagiandata) {
			echo $pembagiandata.",";
		}
		echo "<br>min =>".$min."<br>";
		echo "max =>".$max."<br>";
		echo "<hr>";
	}

	$final1=min($ex);
	$final2=max($ex);
	echo "MIN MAX DARI SEMUA DATA ";
	echo "(min = ".$final1.") (max = ".$final2.")";

 ?>