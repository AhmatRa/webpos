<?php 
function tulis(){
	$fp = fopen('file.txt', 'a');
	$tab="\n";
	fwrite($fp, $val);
	fwrite($fp, $tab);
	fclose($fp);
}
function sejumlah($leng){
	for($a=1; $a<=$leng; $a++)
	{
		tulis($a);
	}
	
}

function hapus(){
	$fp = fopen('file.txt', 'w');
	fwrite($fp, "");
	fclose($fp);
}

 ?>

 <form action="" method="GET" name="leng">
	<label>JUMLAH DATA</label><br><br>
	<input type="text" name="va" placeholder="example 500"><br><br>
	<button name="hit">PRINT</button>
</form>
<?php 
$va=$_GET['va'];
$cek='file.txt';



 ?>