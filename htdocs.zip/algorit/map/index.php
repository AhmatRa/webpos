<center>
	<table>
		<tr><img src="img.png"></tr>
	</table>
<?php 
$jalur="A";
$x1=10; $x2=5; $x3=3; $x4=5; $x6=2; $x7=6; $x8=1;
$x5=3;
	if ($x1 > $x2) 
	{
		$jj=$jalur." -> B";
		if($x4 > $x3)
		{
			$jjj=$jj." -> D";
			if($x6 > $x8)
			{
				$jjjj=$jjj." -> E -> F";
				echo "RUTE TERPANJANG"."<br>";
				echo $jjjj."<br>";
			}
		}
	}
	if ($x2 < $x1)
	{
		$g=$jalur." -> C -> D";
		if($x8 < $x6)
		{
			$gg=$g." -> F";
			echo "<br>"."RUTE TERPENDEK"."<br>";
			echo $gg."<br><br>";
			echo "<br>"."SEMUA RUTE"."<br>";
			echo $jjjj."<br>";
			echo "A -> B -> E -> F"."<br>";
			echo "A -> B -> D -> F"."<br>";
			echo $gg."<br>";
		}
	}
 ?>
</center>