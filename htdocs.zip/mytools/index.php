<?php 
function get_data($url){
 $ch = curl_init();
 $timeout = 5;
  curl_setopt($ch,CURLOPT_URL,$url);
  curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
  curl_setopt($ch,CURLOPT_CONNECTTIMEOUT,$timeout);
  curl_setopt($ch,CURLOPT_USERAGENT,'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.13) Gecko/20080311 Firefox/2.0.0.13');
 $data = curl_exec($ch);
  curl_close($ch);
 return $data;
}
 ?>
 <center>
 	 <form action="" method="GET">
 	 	<br><br>
 	 	<input type="text" name="uri" size="100"><br><br>
 	 	<button name="take">SHOOT</button>
 	 </form>
 </center>

 <?php 
$uri=$_GET['uri'];

if (isset($_GET['take'])) {
	echo get_data($uri);
}

  ?>
