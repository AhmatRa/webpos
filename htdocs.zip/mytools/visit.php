<?php 
$b=1;
$uri="https://digitask.ru/autofaucet3/faucet.php?address=DFchPwHUJgpbpzyLKfzLbLr3v1GBr1KTXL&g-recaptcha-response=03AOLTBLQxWJTcmatYmD-TnaKM99dbpx54TtlIW7A5u5V_-esfy_o9djam08l6KTYIVbBSyaw5cXgKhomu94FWokWH9JpG22T_NG-QEJcwgQ82EAvIE_fRsoJM5wAaHj6bKp9yBFbime2bVN5nlfe2p2Rg6iV-B8uJfAw6d4bOoWUD1GcXYrSiGQ7iPUPgI68SgY8reqkwF03EAACbnd4FYKin0P0tc_8YTMTLiSKpDgGPCx0bqB5GH05LnueuaOBNG7rbz1Cfv-F5o43Wqr_nnZ4OF3tv0jHEg1iFnRkhGF1-cA_D4BUTnDaMfB41ZlCk_pLJQrfZbsVE&currency=DOGE&key=04bc23a4e53df2070f2f85496d16e518";
	for($i=0; $i<$b; $i++)
	{
		$b+=1;
		echo $b;
		sleep(2);
		print "\n";
		if ($b==65)
		{
			$ch=curl_init();
		//$timeout = 10;
		curl_setopt($ch,CURLOPT_URL,$uri);
		curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
		//curl_setopt($ch,CURLOPT_CONNECTTIMEOUT,$timeout);
		curl_setopt($ch,CURLOPT_USERAGENT,'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.13) Gecko/20080311 Firefox/2.0.0.13');
		$data = curl_exec($ch);
		echo $data;
		curl_close($ch);
		echo"oke";
		}
	}
	sleep(3);
	echo "oke";
 ?>