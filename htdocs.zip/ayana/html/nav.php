<nav>
 	<a href="#">HALAMAN TRANSAKSI</a> |
 	<a href="#">DATA BARANG</a> |
 	<a href="#">ADMIN</a> |
 </nav>