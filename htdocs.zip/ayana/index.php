<?php 

 ?>
 <!DOCTYPE html>
 <html>
 <head>
 	 <?php include 'html/head.php';?>
 	 <link rel="stylesheet" type="text/css" href="html/css/style.css">
 </head>
 <body>
 	<div id="container">
 		<div id="header">
 			<?php include 'html/nav.php';?>
 		</div>
 	</div>
 	<div id="sidebar_kiri">
 		asjdlfkjasdkfj
    </div>
 	
 
 </body>
 </html>